﻿using System.Drawing;

namespace Assignment1_ControlanElevator

{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        //images to load

        Image goingdown = Image.FromFile(@".\DisplayScreenImages\down.gif"); //load images to the program.
        Image goingup = Image.FromFile(@".\DisplayScreenImages\up.gif");
        Image groundfloor = Image.FromFile(@".\DisplayScreenImages\G.png");
        Image firstfloor = Image.FromFile(@".\DisplayScreenImages\1.png");
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Database_Listbox = new System.Windows.Forms.ListBox();
            this.btn_Display_log = new System.Windows.Forms.Button();
            this.btn_clear_log = new System.Windows.Forms.Button();
            this.btn_exit_click = new System.Windows.Forms.Button();
            this.picture_inside_elevator = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.ff_left_panel_door = new System.Windows.Forms.PictureBox();
            this.ff_right_panel_door = new System.Windows.Forms.PictureBox();
            this.gf_right_door_panel = new System.Windows.Forms.PictureBox();
            this.gf_left_door_panel = new System.Windows.Forms.PictureBox();
            this.btn_Down = new System.Windows.Forms.Button();
            this.btn_Up = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.controlpanel_display = new System.Windows.Forms.PictureBox();
            this.btn_Emergency_Alarm = new System.Windows.Forms.Button();
            this.btn_Doors_opening = new System.Windows.Forms.Button();
            this.btn_Doors_closing = new System.Windows.Forms.Button();
            this.btn_G_click = new System.Windows.Forms.Button();
            this.btn_1_click = new System.Windows.Forms.Button();
            this.tmr_GoingUp_Down = new System.Windows.Forms.Timer(this.components);
            this.Doors_Opening_timer = new System.Windows.Forms.Timer(this.components);
            this.Doors_Closing_timer = new System.Windows.Forms.Timer(this.components);
            this.tmr_Closedoors_Liftmoves = new System.Windows.Forms.Timer(this.components);
            this.firstfloor_display = new System.Windows.Forms.PictureBox();
            this.groundfloor_display = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tmr_AutodoorClose = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture_inside_elevator)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ff_left_panel_door)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ff_right_panel_door)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gf_right_door_panel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gf_left_door_panel)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.controlpanel_display)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.firstfloor_display)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groundfloor_display)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.Database_Listbox);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(683, 103);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(693, 519);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Elevator Database Log";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(389, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 29);
            this.label3.TabIndex = 3;
            this.label3.Text = "Action";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(193, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 29);
            this.label2.TabIndex = 2;
            this.label2.Text = "Time";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(29, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Date";
            // 
            // Database_Listbox
            // 
            this.Database_Listbox.FormattingEnabled = true;
            this.Database_Listbox.ItemHeight = 16;
            this.Database_Listbox.Location = new System.Drawing.Point(7, 60);
            this.Database_Listbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Database_Listbox.Name = "Database_Listbox";
            this.Database_Listbox.Size = new System.Drawing.Size(679, 452);
            this.Database_Listbox.TabIndex = 0;
            // 
            // btn_Display_log
            // 
            this.btn_Display_log.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Display_log.Location = new System.Drawing.Point(843, 652);
            this.btn_Display_log.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Display_log.Name = "btn_Display_log";
            this.btn_Display_log.Size = new System.Drawing.Size(137, 36);
            this.btn_Display_log.TabIndex = 1;
            this.btn_Display_log.Text = "Display Log";
            this.btn_Display_log.UseVisualStyleBackColor = true;
            this.btn_Display_log.Click += new System.EventHandler(this.btn_Display_log_Click_1);
            // 
            // btn_clear_log
            // 
            this.btn_clear_log.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear_log.Location = new System.Drawing.Point(1085, 650);
            this.btn_clear_log.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_clear_log.Name = "btn_clear_log";
            this.btn_clear_log.Size = new System.Drawing.Size(137, 37);
            this.btn_clear_log.TabIndex = 2;
            this.btn_clear_log.Text = "Clear Log";
            this.btn_clear_log.UseVisualStyleBackColor = true;
            this.btn_clear_log.Click += new System.EventHandler(this.btn_clear_log_Click);
            // 
            // btn_exit_click
            // 
            this.btn_exit_click.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_exit_click.Location = new System.Drawing.Point(989, 699);
            this.btn_exit_click.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_exit_click.Name = "btn_exit_click";
            this.btn_exit_click.Size = new System.Drawing.Size(93, 36);
            this.btn_exit_click.TabIndex = 3;
            this.btn_exit_click.Text = "Exit";
            this.btn_exit_click.UseVisualStyleBackColor = true;
            this.btn_exit_click.Click += new System.EventHandler(this.btn_exit_click_Click);
            // 
            // picture_inside_elevator
            // 
            this.picture_inside_elevator.Image = ((System.Drawing.Image)(resources.GetObject("picture_inside_elevator.Image")));
            this.picture_inside_elevator.Location = new System.Drawing.Point(157, 451);
            this.picture_inside_elevator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.picture_inside_elevator.Name = "picture_inside_elevator";
            this.picture_inside_elevator.Size = new System.Drawing.Size(144, 240);
            this.picture_inside_elevator.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picture_inside_elevator.TabIndex = 4;
            this.picture_inside_elevator.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(135, 94);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(191, 284);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // ff_left_panel_door
            // 
            this.ff_left_panel_door.Image = ((System.Drawing.Image)(resources.GetObject("ff_left_panel_door.Image")));
            this.ff_left_panel_door.Location = new System.Drawing.Point(157, 122);
            this.ff_left_panel_door.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ff_left_panel_door.Name = "ff_left_panel_door";
            this.ff_left_panel_door.Size = new System.Drawing.Size(72, 237);
            this.ff_left_panel_door.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ff_left_panel_door.TabIndex = 7;
            this.ff_left_panel_door.TabStop = false;
            // 
            // ff_right_panel_door
            // 
            this.ff_right_panel_door.Image = ((System.Drawing.Image)(resources.GetObject("ff_right_panel_door.Image")));
            this.ff_right_panel_door.Location = new System.Drawing.Point(229, 122);
            this.ff_right_panel_door.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ff_right_panel_door.Name = "ff_right_panel_door";
            this.ff_right_panel_door.Size = new System.Drawing.Size(73, 237);
            this.ff_right_panel_door.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ff_right_panel_door.TabIndex = 8;
            this.ff_right_panel_door.TabStop = false;
            // 
            // gf_right_door_panel
            // 
            this.gf_right_door_panel.Image = ((System.Drawing.Image)(resources.GetObject("gf_right_door_panel.Image")));
            this.gf_right_door_panel.Location = new System.Drawing.Point(228, 450);
            this.gf_right_door_panel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gf_right_door_panel.Name = "gf_right_door_panel";
            this.gf_right_door_panel.Size = new System.Drawing.Size(74, 241);
            this.gf_right_door_panel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gf_right_door_panel.TabIndex = 9;
            this.gf_right_door_panel.TabStop = false;
            // 
            // gf_left_door_panel
            // 
            this.gf_left_door_panel.Image = ((System.Drawing.Image)(resources.GetObject("gf_left_door_panel.Image")));
            this.gf_left_door_panel.Location = new System.Drawing.Point(157, 449);
            this.gf_left_door_panel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gf_left_door_panel.Name = "gf_left_door_panel";
            this.gf_left_door_panel.Size = new System.Drawing.Size(72, 242);
            this.gf_left_door_panel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gf_left_door_panel.TabIndex = 10;
            this.gf_left_door_panel.TabStop = false;
            // 
            // btn_Down
            // 
            this.btn_Down.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Down.BackgroundImage")));
            this.btn_Down.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Down.Location = new System.Drawing.Point(360, 572);
            this.btn_Down.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Down.Name = "btn_Down";
            this.btn_Down.Size = new System.Drawing.Size(41, 41);
            this.btn_Down.TabIndex = 11;
            this.btn_Down.UseVisualStyleBackColor = true;
            this.btn_Down.Click += new System.EventHandler(this.btn_Down_Click);
            // 
            // btn_Up
            // 
            this.btn_Up.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Up.BackgroundImage")));
            this.btn_Up.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Up.Location = new System.Drawing.Point(360, 240);
            this.btn_Up.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Up.Name = "btn_Up";
            this.btn_Up.Size = new System.Drawing.Size(41, 41);
            this.btn_Up.TabIndex = 12;
            this.btn_Up.UseVisualStyleBackColor = true;
            this.btn_Up.Click += new System.EventHandler(this.btn_Up_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox2.Controls.Add(this.controlpanel_display);
            this.groupBox2.Controls.Add(this.btn_Emergency_Alarm);
            this.groupBox2.Controls.Add(this.btn_Doors_opening);
            this.groupBox2.Controls.Add(this.btn_Doors_closing);
            this.groupBox2.Controls.Add(this.btn_G_click);
            this.groupBox2.Controls.Add(this.btn_1_click);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(441, 107);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(201, 446);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Elevator Control Panel";
            // 
            // controlpanel_display
            // 
            this.controlpanel_display.BackColor = System.Drawing.Color.Black;
            this.controlpanel_display.Location = new System.Drawing.Point(51, 57);
            this.controlpanel_display.Margin = new System.Windows.Forms.Padding(4);
            this.controlpanel_display.Name = "controlpanel_display";
            this.controlpanel_display.Size = new System.Drawing.Size(95, 86);
            this.controlpanel_display.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.controlpanel_display.TabIndex = 16;
            this.controlpanel_display.TabStop = false;
            // 
            // btn_Emergency_Alarm
            // 
            this.btn_Emergency_Alarm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Emergency_Alarm.BackgroundImage")));
            this.btn_Emergency_Alarm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Emergency_Alarm.Location = new System.Drawing.Point(79, 388);
            this.btn_Emergency_Alarm.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Emergency_Alarm.Name = "btn_Emergency_Alarm";
            this.btn_Emergency_Alarm.Size = new System.Drawing.Size(41, 41);
            this.btn_Emergency_Alarm.TabIndex = 4;
            this.btn_Emergency_Alarm.UseVisualStyleBackColor = true;
            this.btn_Emergency_Alarm.Click += new System.EventHandler(this.btn_Emergency_Alarm_Click);
            // 
            // btn_Doors_opening
            // 
            this.btn_Doors_opening.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Doors_opening.BackgroundImage")));
            this.btn_Doors_opening.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Doors_opening.Location = new System.Drawing.Point(116, 315);
            this.btn_Doors_opening.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Doors_opening.Name = "btn_Doors_opening";
            this.btn_Doors_opening.Size = new System.Drawing.Size(41, 41);
            this.btn_Doors_opening.TabIndex = 3;
            this.btn_Doors_opening.UseVisualStyleBackColor = true;
            this.btn_Doors_opening.Click += new System.EventHandler(this.btn_Doors_opening_Click);
            // 
            // btn_Doors_closing
            // 
            this.btn_Doors_closing.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Doors_closing.BackgroundImage")));
            this.btn_Doors_closing.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Doors_closing.Location = new System.Drawing.Point(40, 315);
            this.btn_Doors_closing.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Doors_closing.Name = "btn_Doors_closing";
            this.btn_Doors_closing.Size = new System.Drawing.Size(41, 41);
            this.btn_Doors_closing.TabIndex = 2;
            this.btn_Doors_closing.UseVisualStyleBackColor = true;
            this.btn_Doors_closing.Click += new System.EventHandler(this.btn_Doors_closing_Click);
            // 
            // btn_G_click
            // 
            this.btn_G_click.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_G_click.BackgroundImage")));
            this.btn_G_click.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_G_click.Location = new System.Drawing.Point(79, 246);
            this.btn_G_click.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_G_click.Name = "btn_G_click";
            this.btn_G_click.Size = new System.Drawing.Size(41, 41);
            this.btn_G_click.TabIndex = 1;
            this.btn_G_click.UseVisualStyleBackColor = true;
            this.btn_G_click.Click += new System.EventHandler(this.btn_G_click_Click);
            // 
            // btn_1_click
            // 
            this.btn_1_click.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_1_click.BackgroundImage")));
            this.btn_1_click.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_1_click.Location = new System.Drawing.Point(79, 172);
            this.btn_1_click.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_1_click.Name = "btn_1_click";
            this.btn_1_click.Size = new System.Drawing.Size(41, 41);
            this.btn_1_click.TabIndex = 0;
            this.btn_1_click.UseVisualStyleBackColor = true;
            this.btn_1_click.Click += new System.EventHandler(this.btn_1_click_Click);
            // 
            // tmr_GoingUp_Down
            // 
            this.tmr_GoingUp_Down.Interval = 5;
            this.tmr_GoingUp_Down.Tick += new System.EventHandler(this.tmr_GoingUp_Down_Tick);
            // 
            // Doors_Opening_timer
            // 
            this.Doors_Opening_timer.Interval = 5;
            this.Doors_Opening_timer.Tick += new System.EventHandler(this.Doors_Opening_timer_Tick);
            // 
            // Doors_Closing_timer
            // 
            this.Doors_Closing_timer.Interval = 5;
            this.Doors_Closing_timer.Tick += new System.EventHandler(this.Doors_Closing_timer_Tick);
            // 
            // tmr_Closedoors_Liftmoves
            // 
            this.tmr_Closedoors_Liftmoves.Interval = 1000;
            this.tmr_Closedoors_Liftmoves.Tick += new System.EventHandler(this.tmr_Closedoors_Liftmoves_Tick);
            // 
            // firstfloor_display
            // 
            this.firstfloor_display.BackColor = System.Drawing.Color.Black;
            this.firstfloor_display.Location = new System.Drawing.Point(208, 94);
            this.firstfloor_display.Margin = new System.Windows.Forms.Padding(4);
            this.firstfloor_display.Name = "firstfloor_display";
            this.firstfloor_display.Size = new System.Drawing.Size(39, 20);
            this.firstfloor_display.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.firstfloor_display.TabIndex = 17;
            this.firstfloor_display.TabStop = false;
            // 
            // groundfloor_display
            // 
            this.groundfloor_display.BackColor = System.Drawing.Color.Black;
            this.groundfloor_display.Location = new System.Drawing.Point(207, 420);
            this.groundfloor_display.Margin = new System.Windows.Forms.Padding(4);
            this.groundfloor_display.Name = "groundfloor_display";
            this.groundfloor_display.Size = new System.Drawing.Size(39, 20);
            this.groundfloor_display.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.groundfloor_display.TabIndex = 18;
            this.groundfloor_display.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(135, 420);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(191, 290);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Kristen ITC", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(20, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 144);
            this.label4.TabIndex = 19;
            this.label4.Text = "F  F\r\nI  L\r\nR O\r\nS O\r\nT R\r\n   \r\n";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Kristen ITC", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(21, 449);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 144);
            this.label5.TabIndex = 20;
            this.label5.Text = "G\r\nR F\r\nO L\r\nU O\r\nN O\r\nD R\r\n";
            // 
            // tmr_AutodoorClose
            // 
            this.tmr_AutodoorClose.Interval = 5000;
            this.tmr_AutodoorClose.Tick += new System.EventHandler(this.tmr_AutodoorClose_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1460, 762);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groundfloor_display);
            this.Controls.Add(this.firstfloor_display);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btn_Up);
            this.Controls.Add(this.btn_Down);
            this.Controls.Add(this.gf_left_door_panel);
            this.Controls.Add(this.gf_right_door_panel);
            this.Controls.Add(this.ff_right_panel_door);
            this.Controls.Add(this.ff_left_panel_door);
            this.Controls.Add(this.picture_inside_elevator);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btn_exit_click);
            this.Controls.Add(this.btn_clear_log);
            this.Controls.Add(this.btn_Display_log);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Control an Elevator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture_inside_elevator)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ff_left_panel_door)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ff_right_panel_door)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gf_right_door_panel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gf_left_door_panel)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.controlpanel_display)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.firstfloor_display)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groundfloor_display)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox Database_Listbox;
        private System.Windows.Forms.Button btn_Display_log;
        private System.Windows.Forms.Button btn_clear_log;
        private System.Windows.Forms.Button btn_exit_click;
        private System.Windows.Forms.PictureBox picture_inside_elevator;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox ff_left_panel_door;
        private System.Windows.Forms.PictureBox ff_right_panel_door;
        private System.Windows.Forms.PictureBox gf_right_door_panel;
        private System.Windows.Forms.PictureBox gf_left_door_panel;
        private System.Windows.Forms.Button btn_Down;
        private System.Windows.Forms.Button btn_Up;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_Emergency_Alarm;
        private System.Windows.Forms.Button btn_Doors_opening;
        private System.Windows.Forms.Button btn_Doors_closing;
        private System.Windows.Forms.Button btn_G_click;
        private System.Windows.Forms.Button btn_1_click;
        private System.Windows.Forms.Timer tmr_GoingUp_Down;
        private System.Windows.Forms.Timer Doors_Opening_timer;
        private System.Windows.Forms.Timer Doors_Closing_timer;
        private System.Windows.Forms.Timer tmr_Closedoors_Liftmoves;
        private System.Windows.Forms.PictureBox controlpanel_display;
        private System.Windows.Forms.PictureBox firstfloor_display;
        private System.Windows.Forms.PictureBox groundfloor_display;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Timer tmr_AutodoorClose;
    }
}

