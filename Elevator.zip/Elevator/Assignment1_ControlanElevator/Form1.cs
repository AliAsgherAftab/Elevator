﻿//Name: Ali Asgher Aftab
//Student ID: 1434245

//These below are the libraries for the system.
using System;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Windows.Forms;
using System.Speech;
using System.Speech.Synthesis;

namespace Assignment1_ControlanElevator
{
    public partial class Form1 : Form
    {
        int currentFloor = 0; //This Variable is used to get to know the current floor.

        //These boolean variables are used in sending instructions to the system
        private bool goingUp = false;
        private bool goingDown = false;
        bool firstFloordoorOpen = false;
        bool groundFloordoorOpen = false;


        SpeechSynthesizer Sound = new SpeechSynthesizer(); //Creating an object named as Sound for speech synthesizer 
        public Form1()
        {
            InitializeComponent(); //Initializes all components in the form   
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ImageGroundFloor();
        }

        //************** DiplayScreen Images functions******************/////

        //This method is created to displaying the moving up indication on the display screen
        public void ImageGroundFloor()
        {
            controlpanel_display.Image = groundfloor;
            groundfloor_display.Image = groundfloor;
            firstfloor_display.Image = groundfloor;
        }
        //This is method is created to display 1 on the display screen
        public void ImageFirstFloor()
        {
            controlpanel_display.Image = firstfloor;
            groundfloor_display.Image = firstfloor;
            firstfloor_display.Image = firstfloor;
        }
        //This method is created to displaying the moving down indication on the display screen
        public void ImageGoingUp()
        {
            controlpanel_display.Image = goingup;
            groundfloor_display.Image = goingup;
            firstfloor_display.Image = goingup;
        }
        //This method is created to display the emergency bell icon on the display screen
        public void ImageGoingDown()
        {
            controlpanel_display.Image = goingdown;
            groundfloor_display.Image = goingdown;
            firstfloor_display.Image = goingdown;
        }



        //******************Validations**************//
        //Creating methods for preventing program from crashing

        //This method is diabling the buttons while lift is moving up and down
        private void disGoingUp()
        {
            btn_Up.Enabled = false;
            btn_Down.Enabled = false;
            btn_1_click.Enabled = false;
            btn_G_click.Enabled = false;            
            btn_Doors_opening.Enabled = false;
            btn_Doors_closing.Enabled = false;            
        }
        //This method is diabling the buttons while lift is moving up and down
        private void disGoingDown()
        {
            btn_Up.Enabled = false;
            btn_Down.Enabled = false;
            btn_1_click.Enabled = false;
            btn_G_click.Enabled = false;
            btn_Doors_opening.Enabled = false;
            btn_Doors_closing.Enabled = false;
        }

        //This method is Enabling the buttons when lift arrives at first floor
        private void arrivalFirstFLoor()
        {
            btn_Up.Enabled = true;
            btn_Down.Enabled = true;
            btn_1_click.Enabled = true;
            btn_G_click.Enabled = true;
            btn_Doors_opening.Enabled = true;
            btn_Doors_closing.Enabled = true;
            btn_Up.BackColor = Color.White;
            btn_1_click.BackColor = Color.White;
        }

        //This method is Enabling the buttons when lift arrives at ground floor
        private void arrivalGroundFLoor()
        {
            btn_Up.Enabled = true;
            btn_Down.Enabled = true;           
            btn_1_click.Enabled = true;
            btn_G_click.Enabled = true;
            btn_Doors_opening.Enabled = true;
            btn_Doors_closing.Enabled = true;
            btn_Down.BackColor = Color.White;
            btn_G_click.BackColor = Color.White;
        }

        private void EmergencyButtonclick()
        {
            btn_Up.Enabled = true;
            btn_Down.Enabled = true;
            btn_1_click.Enabled = true;
            btn_G_click.Enabled = true;
            btn_Doors_opening.Enabled = true;
            btn_Doors_closing.Enabled = true;
            btn_Up.BackColor = Color.White;
        }



        // *************Buttons***********/////
        //This is the button up click event for requesting the lift to come up
        private void btn_Up_Click(object sender, EventArgs e)
        {
            btn_Up.BackColor = Color.Red;

            //Checks the timer for going up and down, and doors opening timer are true and it returns
            if (tmr_GoingUp_Down.Enabled == true || Doors_Opening_timer.Enabled == true) 
            {
                return;
            }

            ImageGoingUp(); //Displaying the going up indication on the display screen while lift is going up
           
            if (groundFloordoorOpen == false) //Checks the if statement to verify if it is false
            {
                goingUp = true; //It allows the lift to go up
                tmr_GoingUp_Down.Start(); //Timer starts and lift goes up
                //Sound.Speak("Lift Going Up");
                insertIntoDB("Lift Going Up"); //Inserting data in the insert method data for database
                disGoingUp(); //Calling the method to disable the buttons while lift is going up.
            }
           
            else if (groundFloordoorOpen == true) //Checks if the ground floor doors are open
            {
                Doors_Closing_timer.Start(); //The timer starts to close the door
                tmr_Closedoors_Liftmoves.Start(); //The timer starts and closes the doors if they are open and lift moves up
                insertIntoDB("Doors Closing at Ground Floor"); //Inserting data in the insert method data for database
                insertIntoDB("Lift Going Up");  //Inserting data in the insert method data for database
                disGoingUp(); //Calling the method to disable the buttons while lift is going up.
            
        }
        }
        
        //This is the button down click event for requesting the lift to come down
        private void btn_Down_Click(object sender, EventArgs e)
        {
            btn_Down.BackColor = Color.Red;

            //Checks the timer for going up and down, and doors opening timer are true and it returns
            if (tmr_GoingUp_Down.Enabled==true || Doors_Opening_timer.Enabled == true)
            {
                return;
            }
            ImageGoingDown(); //Displaying the going down indication on the display screen while lift is going down

            if (firstFloordoorOpen == false) //Checks the if statement to verify if it is false
            {
                goingDown = true; //It allows the lift to go down
                tmr_GoingUp_Down.Start(); //Timer starts and lift goes up
                
                disGoingDown(); //Calling the method to disable the buttons while lift is going down.
            }
            else if (firstFloordoorOpen == true) //Checks if the first floor doors are open
            {
                Doors_Closing_timer.Start(); //The timer starts to close the doors
                tmr_Closedoors_Liftmoves.Start();  //The timer starts and closes the doors if they are open and lift moves down             
                insertIntoDB("Doors Closing at First Floor");  //Inserting data in the insert method data for database
                insertIntoDB("Lift Going Down");  //Inserting data in the insert method data for database
                disGoingDown();  //Calling the method to disable the buttons while lift is going down.
            }
        }
        
        //This is the button up click event for the lift to go at first floor
        private void btn_1_click_Click(object sender, EventArgs e)
        {
            btn_1_click.BackColor = Color.Red;

            //Checks the timer for going up and down, and doors opening timer are true and it returns
            if (tmr_GoingUp_Down.Enabled == true || Doors_Opening_timer.Enabled == true)
            {
              //  Doors_Closing_timer.Start();
              //  tmr_GoingUp_Down.Start();
                return;
            }
            ImageGoingUp();  //Displaying the going up indication on the display screen while lift is going up

            if (groundFloordoorOpen == false || groundFloordoorOpen ==true) //Checks the if statement to verify if it is false
            {
                goingUp = true;  //It allows the lift to go down
                tmr_GoingUp_Down.Start(); //Timer starts and lift goes up
                disGoingUp(); //Calling the method to disable the buttons while lift is going up.
            }
            if (currentFloor == 0) //It checks if current floor is at ground floor 
            {
                insertIntoDB("Lift Going Up"); //Inserting data in the insert method data for database
            }
            else if (groundFloordoorOpen == true) //Checks the if statement to verify if it is true
            {
                Doors_Closing_timer.Start();  //This timer closes the doors
                tmr_Closedoors_Liftmoves.Start(); //This timer closes the doors first and then it moves
                insertIntoDB("Doors Closing at Ground Floor"); //Inserting data in the database
                insertIntoDB("Lift Going Up");  //Inserting data in the insert method data for database
                disGoingUp(); //Calling the method to disable the buttons while lift is going up.
            }
        }
       
        //This is the button G click event for the lift to go down
        private void btn_G_click_Click(object sender, EventArgs e)
        {
            btn_G_click.BackColor = Color.Red;

            //Checks the timer for going up and down, and doors opening timer are true and it returns
            if (tmr_GoingUp_Down.Enabled == true || Doors_Opening_timer.Enabled == true)
            {
                return;
            }     
            
            ImageGoingDown();  //Displaying the going down indication on the display screen while lift is going down

            if (firstFloordoorOpen == false) //This if statement checks the first floor doors are not open
            {
                goingDown = true;  //It allows the lift to go down
                tmr_GoingUp_Down.Start(); //Timer starts and lift goes down              
                disGoingDown();  //Calling the method to disable the buttons while lift is going down
            }
            else if (firstFloordoorOpen == true) //Checks the if statement to verify if it is true
            {
                Doors_Closing_timer.Start();  //This timer closes the doors
                tmr_Closedoors_Liftmoves.Start();  //This timer closes the doors first and then it moves
                insertIntoDB("Doors Closing at First Floor");  //Inserting data in the database
                insertIntoDB("Lift Going Down");  //Inserting data in the database
                disGoingDown(); //Calling the method to disable the buttons while lift is going down.
            }
            
        }
        
        //This is the button click event for closing the doors
        private void btn_Doors_closing_Click(object sender, EventArgs e)
        {

            if (tmr_GoingUp_Down.Enabled == true) //This if statement checks the timer going up and down is enabled and then it returns
            {
                return;
            }
            btn_Doors_closing.BackColor = Color.Red;

            Doors_Opening_timer.Stop();  //Doors opening timer stops
            Doors_Closing_timer.Start(); //Doors closing timer starts
            if (currentFloor == 0) //This if statement checks the current floor is 0
            {
                insertIntoDB("Doors Closing at Ground Floor");  //Inserting data in the insert method data for database
            }
            else
            {
                insertIntoDB("Doors Closing at First Floor");   //Inserting data in the insert method data for database
                btn_Doors_closing.BackColor = Color.White;

            }
        }
        
        //This is the button click event for opening the doors
        private void btn_Doors_opening_Click(object sender, EventArgs e)
        {
            if (tmr_GoingUp_Down.Enabled == true) //This if statement checks the timer going up and down is enabled and then it returns
            {
                
                return;
            }
            Doors_Closing_timer.Stop();  //Doors closing timer stops
            Doors_Opening_timer.Start();  //Doors opening timer starts
            tmr_AutodoorClose.Start();  //Automatic door closing timer starts after 5secs

            btn_Doors_opening.BackColor = Color.Red;


            if (currentFloor == 0)  //This if statement checks if the current floor is 0 it returns
            {
                return;
            }
            else
            {                
                insertIntoDB("Doors Opening at First Floor");  //Inserting data in the insert method data for database
                                                            
                btn_Doors_opening.BackColor = Color.White;
            }

        }

        //This is the button Emergency Alarm click event 
        private void btn_Emergency_Alarm_Click(object sender, EventArgs e)
        {
            btn_Emergency_Alarm.BackColor = Color.Red;
            goingUp = false; //Calling the method to enable the emergency button
            goingDown = false;  //Calling the method to enable the emergency button
            Doors_Opening_timer.Enabled = true; //Timer starts for opening the doors
            Sound.Speak("Emergency Stop. Please Exit Carefully");  //Its a voice for emergency
            tmr_Closedoors_Liftmoves.Stop(); //This timer stops
            tmr_GoingUp_Down.Stop();   //This timer stops
            Doors_Opening_timer.Start();  //This timer starts and opens the doors    
            btn_Emergency_Alarm.BackColor = Color.White;
            insertIntoDB("Emergency Alarm! Doors Opening"); //Inserting data in the insert method data for database
        }



        //*******************Timers******************////
        private void tmr_GoingUp_Down_Tick(object sender, EventArgs e) //Going Up method for the elevator.
        { 
                if (goingUp == true)  //Checking if statement equals true
                {
                    if (picture_inside_elevator.Top >= 100)
                    {
                        picture_inside_elevator.Top -= 1;

                        if (goingUp == true)
                        {
                         Doors_Closing_timer.Enabled = true;  //Doors closing timer starts
                        }
                    }
                    else
                    {
                        tmr_GoingUp_Down.Enabled = false;  //Timer stops
                        tmr_Closedoors_Liftmoves.Stop(); //Timer Stops

                        currentFloor = 1;  
                        goingUp = false;

                        ImageFirstFloor();  //Displays the current position of the elevator

                        Doors_Opening_timer.Start();  //Timer starts
                        Doors_Closing_timer.Enabled = false; //Timer stops

                        tmr_AutodoorClose.Start();  //Timer starts
                        arrivalFirstFLoor();  //Calls the method and Enabling all the buttons back for use
                    }
                }
            
            if (goingDown == true)  //going Down method.
            {
                if (picture_inside_elevator.Top <= 365)
                {
                    picture_inside_elevator.Top += 1;
                    if (goingDown == true)  //Checking if statement is true
                    {
                     Doors_Closing_timer.Enabled = true;  //Door closing timer starts
                    }
                }
                else
                {
                    tmr_GoingUp_Down.Enabled = false;  //Stops the timer
                    tmr_Closedoors_Liftmoves.Stop();  //Stops the timer
                    currentFloor = 0;
                    goingDown = false;

                    ImageGroundFloor();  //Displays the current position of the elevator

                    Doors_Opening_timer.Start();  //Timer starts
                    tmr_AutodoorClose.Start();  //Timer starts
                    arrivalGroundFLoor();  //Calls the method and Enabling all the buttons back for use
                }
            }             
        }

        private void Doors_Opening_timer_Tick(object sender, EventArgs e) //Doors opening method/timer for the elevator.
        {
            EmergencyButtonclick();

            
            btn_Emergency_Alarm.BackColor = Color.White;

            if (currentFloor == 1) //This if statement checks the current floor equals 1
            {
                if (ff_left_panel_door.Left >= 78 && ff_right_panel_door.Left <= 300) //This if statement checks the alignment of the door
                {
                    ff_left_panel_door.Left -= 1;
                    ff_right_panel_door.Left += 1;
                }
                else
                {
                    Doors_Opening_timer.Enabled = false; 
                    firstFloordoorOpen = true;
                    insertIntoDB("Doors Opening at First Floor");  //Inserting data in the insert method data for database
                }
            }

            if (currentFloor == 0)  //This if statement checks the current floor equals 0
            {
                if (gf_left_door_panel.Left >= 78 && gf_right_door_panel.Left <= 300)
                {
                    gf_left_door_panel.Left -= 1;
                    gf_right_door_panel.Left += 1;
                    
                }
                else
                {
                    Doors_Opening_timer.Enabled = false;
                    groundFloordoorOpen = true;
                    insertIntoDB("Doors Opening at Ground Floor");  //Inserting data in the insert method data for database
                }
            }
        }

        private void Doors_Closing_timer_Tick(object sender, EventArgs e)   //doors closing method/timer.
        {


            if (currentFloor == 1)  //This if statement checks the current floor equals 1
            {
                if (ff_left_panel_door.Left <= 118) // This if statement checks the alignment of the door
                {
                    ff_left_panel_door.Left += 1;
                    ff_right_panel_door.Left -= 1;
                }
                else
                {
                    Doors_Closing_timer.Enabled = false;
                    firstFloordoorOpen = false;
                    tmr_AutodoorClose.Stop();                   
                }
             }

            if (currentFloor == 0)  //This if statement checks the current floor equals 0
            {
                if (gf_left_door_panel.Left <= 118)  // This if statement checks the alignment of the door
                {
                    gf_left_door_panel.Left += 1;
                    gf_right_door_panel.Left -= 1;
                }
                else
                {
                    Doors_Closing_timer.Enabled = false;
                    groundFloordoorOpen = false;
                    tmr_AutodoorClose.Stop();
                    if (gf_left_door_panel.Left == 118)
                    {
                        insertIntoDB("Doors Closing at First Floor");  //Inserting data in the insert method data for database
                    }
                }
            }
         }
        
        private void tmr_Closedoors_Liftmoves_Tick(object sender, EventArgs e)    //timer for timing the lift for working before it goes down and up.
        {
            if (currentFloor == 1)  // This if statement checks the current floor equals 1
            {
                goingDown = true;
                tmr_GoingUp_Down.Start();  //Timer start lift goes down
            }
            if (currentFloor == 0)  // This if statement checks the current floor equals 1
            {
                goingUp = true;
                tmr_GoingUp_Down.Start();  //Timer starts lift goes up
            }
            
        }
        private void tmr_AutodoorClose_Tick(object sender, EventArgs e)
        {
            if (currentFloor == 1)   //This if statement checks the current floor equals 1
            {
                Doors_Closing_timer.Start();  //Timer start door close
                insertIntoDB("Doors Closing at First Floor");   //Inserting data in the insert method data for database
            }
            if (currentFloor == 0)   //This if statement checks the current floor equals 1
            {
                Doors_Closing_timer.Start();  // Timer start door close
                insertIntoDB("Doors Closing at Ground Floor");   //Inserting data in the insert method data for database
            }
        }
        
        //The button click event to exit the program
        private void btn_exit_click_Click(object sender, EventArgs e)
        {
            this.Close();  //Ends the program running
        }



        ////Database

        //private bool filled;
        DataSet dataset = new DataSet();
        string dbconnection = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=ControlanElevatorDatabase.accdb;";        
        private void btn_Display_log_Click_1(object sender, EventArgs e)
        {
            Database_Listbox.Items.Clear();

           
           
            string dbcommand = "Select * from ElevatorDatabase;";
            OleDbConnection dbcon = new OleDbConnection(dbconnection);
            OleDbCommand dbcom = new OleDbCommand(dbcommand, dbcon);

            try
            {
                OleDbDataAdapter dbadapter = new OleDbDataAdapter(dbcom);
                dbcon.Open();
                //MessageBox.Show("Connection made Successfully!!!");

                dbadapter.Fill(dataset);
                DataTable datatable = dataset.Tables[0];

                foreach (DataRow row in datatable.Rows)
                {
                    Database_Listbox.Items.Add(row["Date"] + "\t\t" + row["Time"] + "\t\t\t" + row["ElevatorOperation"]);
                }
            }
            catch (Exception ex)
            {
                string message = "Error in connection to DataBase. " + ex.Message;
                string caption = "Error";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBox.Show(message, caption, buttons);
            }
            finally
            {
                dbcon.Close();
            }
        }
        
        private void insertIntoDB(string elevator_operation)
        {
            string date = string.Format("{0:dd/MM/yyyy}", DateTime.Now);
            string time = string.Format("{0:T}", DateTime.Now);
            string dbInsertCommand = "insert into [ElevatorDatabase] ([Date],[Time],[ElevatorOperation]) values( @Date, @Time,@ElevatorOperation)";
            
            OleDbConnection dbcon = new OleDbConnection(dbconnection);
            OleDbCommand dbcom = new OleDbCommand(dbInsertCommand, dbcon);

            try
            {
                OleDbDataAdapter adapter = new OleDbDataAdapter(dbcom);
                
                dbcom.Parameters.AddWithValue("@Date", date);
                dbcom.Parameters.AddWithValue("@Time", time);
                dbcom.Parameters.AddWithValue("@ElevatorOperation", elevator_operation);

                dbcon.Open();

                dbcom.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                string message = "Error in connection to DataBase. " + ex.Message;
                string caption = "Error";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBox.Show(message, caption, buttons);
            }
            finally
            {
                dbcon.Close();
            }

            Database_Listbox.Items.Add(date + "\t\t" + time + "\t\t\t" + elevator_operation);
        }

        private void btn_clear_log_Click(object sender, EventArgs e)
        {
            Database_Listbox.Items.Clear();
        }

        
    }
}


